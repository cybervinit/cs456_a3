
class link:
    lid = 0
    cost = 0
    def __init__(self, lid, cost):
        self.lid = lid
        self.cost = cost

